import { Container, Flex, Image, Text } from "@mantine/core";
import unionIcon from "../assets/icons/union.png.png";
import { FaChevronDown } from "react-icons/fa";
import { Link } from "react-router-dom";

function Headerbottom() {
  const categories = [
    { name: "Muddatli to'lov", path: "/category/muddatliTolov", icon: unionIcon, isSpecial: true },
    { name: "Elektronika", path: "/category/elektronika" },
    { name: "Arzon narxlar", path: "/category/arzonNarx" },
    { name: "Issiq Texnika", path: "/category/issiqTexnika" },
    { name: "Maishiy texnika", path: "/category/issiqTexnika" },
    { name: "Kiyim", path: "/category/arzonNarx" },
    { name: "Poyabzallar", path: "/category/arzonNarx" },
    { name: "Aksessuarlar", path: "/category/elektronika" },
    { name: "Goʻzallik va parvarish", path: "/category/arzonNarx" },
    { name: "Salomatlik", path: "/category/arzonNarx" },
  ];

  return (
    <Container size="100%" px={140} mt={14}>
      <Flex justify="space-between" align="center" style={{ overflowX: "auto", paddingBottom: "4px" }}>
        <Flex gap={28} align="center">
          {categories.map((cat, idx) => (
            <Link
              key={idx}
              to={cat.path}
              style={{
                textDecoration: "none",
                display: "flex",
                alignItems: "center",
                whiteSpace: "nowrap",
                transition: "color 0.2s ease",
              }}
            >
              {cat.icon && (
                <Image w={22} mr={6} src={cat.icon} alt={cat.name} />
              )}
              <Text
                size="14.5px"
                fw={cat.isSpecial ? 600 : 400}
                style={{
                  color: cat.isSpecial ? "#7000FF" : "#1f2026",
                  transition: "color 0.2s ease",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.color = "#7000FF")}
                onMouseLeave={(e) => (e.currentTarget.style.color = cat.isSpecial ? "#7000FF" : "#1f2026")}
              >
                {cat.name}
              </Text>
            </Link>
          ))}
        </Flex>
        <Flex
          align="center"
          gap={5}
          style={{
            cursor: "pointer",
            color: "#8B8E99",
            fontSize: "14px",
            whiteSpace: "nowrap",
            marginLeft: "15px",
          }}
        >
          <Text size="14px">Yana</Text>
          <FaChevronDown size={12} />
        </Flex>
      </Flex>
    </Container>
  );
}

export default Headerbottom;
